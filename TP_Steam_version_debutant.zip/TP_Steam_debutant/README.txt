TP Steam — version débutant

1. Décompresse le fichier ZIP.
2. Ouvre le fichier email.html avec Chrome.
3. Clique sur « VOIR LE MESSAGE ».
4. La page sensibilisation.html s'ouvre et explique les bons réflexes.

Les deux pages sont des maquettes locales. Le lien ne va pas sur Internet et aucun identifiant n'est collecté.
Cette maquette n'est pas un message officiel de Steam et ne doit pas être envoyée à une personne réelle sans autorisation explicite du responsable du TP.
