# Documentation technique — TP phishing (niveau débutant)

## Objectif
Créer une maquette de courriel et une page simple qui explique comment reconnaître le phishing.

## Fichiers
- `email.html` : la maquette du mail.
- `sensibilisation.html` : la page affichée après le clic.
- `README.txt` : les étapes pour tester.

## Fonctionnement
Le mail est écrit en HTML. Les couleurs et les espaces sont définis directement avec l'attribut `style`.
Le bouton est un lien HTML : `href="sensibilisation.html"`. Il ouvre la deuxième page qui se trouve dans le même dossier.

## Prévention
La page explique quatre réflexes : vérifier l'expéditeur, se méfier de l'urgence, vérifier les liens et ne jamais transmettre son mot de passe depuis un lien reçu par mail.

## Sécurité
Il s'agit d'une démonstration locale. Aucun formulaire, collecte de mot de passe, suivi de clic ou envoi réel n'est présent. La maquette n'est pas affiliée à Steam.
